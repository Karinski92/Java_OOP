package zoo.entities.areas;

public class WaterArea extends BaseArea {

    private static final int CAPACITY = 10;

    protected WaterArea(String name) {
        super(name, CAPACITY);
    }
}
